# Large BVAR

A Python package to implement large Bayesian Vector Autoregressive (BVAR) models.

## Installation

You can install the package via pip:

```bash
pip install covbayesvar
